import { Heart } from 'lucide-react';

export function Footer() {
  return (
    <footer className="border-t border-border/40 bg-muted/30">
      <div className="container py-12">
        <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-gradient-to-br from-primary to-accent">
                <span className="text-xl font-bold text-primary-foreground">ॐ</span>
              </div>
              <div className="flex flex-col">
                <span className="font-bold leading-tight">ज्योतिष अनुष्ठान</span>
                <span className="text-xs text-muted-foreground">कर्मकांड केंद्र</span>
              </div>
            </div>
            <p className="text-sm text-muted-foreground">
              वैदिक परंपरा के अनुसार सभी प्रकार के धार्मिक अनुष्ठान और ज्योतिषीय सेवाएं
            </p>
          </div>

          <div>
            <h3 className="font-semibold mb-4">त्वरित लिंक</h3>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li>
                <button
                  onClick={() => document.getElementById('home')?.scrollIntoView({ behavior: 'smooth' })}
                  className="hover:text-primary transition-colors"
                >
                  मुख्य पृष्ठ
                </button>
              </li>
              <li>
                <button
                  onClick={() => document.getElementById('services')?.scrollIntoView({ behavior: 'smooth' })}
                  className="hover:text-primary transition-colors"
                >
                  सेवाएं
                </button>
              </li>
              <li>
                <button
                  onClick={() => document.getElementById('about')?.scrollIntoView({ behavior: 'smooth' })}
                  className="hover:text-primary transition-colors"
                >
                  हमारे बारे में
                </button>
              </li>
              <li>
                <button
                  onClick={() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' })}
                  className="hover:text-primary transition-colors"
                >
                  संपर्क करें
                </button>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="font-semibold mb-4">सेवाएं</h3>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li>हवन और यज्ञ</li>
              <li>ज्योतिष परामर्श</li>
              <li>पूजा-पाठ</li>
              <li>विवाह संस्कार</li>
              <li>वास्तु परामर्श</li>
            </ul>
          </div>

          <div>
            <h3 className="font-semibold mb-4">संपर्क</h3>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li>फोन: +91 98765 43210</li>
              <li>ईमेल: info@jyotishkendra.com</li>
              <li>समय: सुबह 6:00 - शाम 8:00</li>
              <li>नई दिल्ली, भारत</li>
            </ul>
          </div>
        </div>

        <div className="mt-12 pt-8 border-t border-border/40 text-center text-sm text-muted-foreground">
          <p className="flex items-center justify-center gap-1 flex-wrap">
            © 2025. Built with <Heart className="h-4 w-4 text-red-500 inline" /> using{' '}
            <a
              href="https://caffeine.ai"
              target="_blank"
              rel="noopener noreferrer"
              className="text-primary hover:underline"
            >
              caffeine.ai
            </a>
          </p>
        </div>
      </div>
    </footer>
  );
}
