import { Card, CardContent } from '@/components/ui/card';
import { CheckCircle2 } from 'lucide-react';

const features = [
  'अनुभवी और विद्वान पंडितों की टीम',
  'शास्त्रोक्त विधि से संपन्न अनुष्ठान',
  'सभी प्रकार की पूजा सामग्री की व्यवस्था',
  'घर और मंदिर दोनों स्थानों पर सेवा उपलब्ध',
  'उचित मूल्य और पारदर्शिता',
  'समय की पाबंदी और गुणवत्ता की गारंटी',
];

export function About() {
  return (
    <section id="about" className="py-20 md:py-28 bg-muted/30">
      <div className="container">
        <div className="grid gap-12 lg:grid-cols-2 lg:gap-16 items-center">
          <div>
            <h2 className="text-3xl font-bold tracking-tight sm:text-4xl md:text-5xl mb-6">
              हमारे बारे में
            </h2>
            <div className="space-y-4 text-lg text-muted-foreground">
              <p>
                ज्योतिष अनुष्ठान कर्मकांड केंद्र में आपका स्वागत है। हम वर्षों से वैदिक परंपरा के अनुसार 
                विभिन्न प्रकार के धार्मिक अनुष्ठान, पूजा-पाठ और ज्योतिषीय परामर्श की सेवाएं प्रदान कर रहे हैं।
              </p>
              <p>
                हमारे अनुभवी और विद्वान पंडितों की टीम शास्त्रोक्त विधि से सभी प्रकार के संस्कार, 
                पूजन और अनुष्ठान संपन्न कराती है। हम अपनी सेवाओं में गुणवत्ता, पारदर्शिता और 
                समय की पाबंदी को सर्वोच्च प्राथमिकता देते हैं।
              </p>
              <p>
                चाहे आपको ज्योतिषीय परामर्श की आवश्यकता हो, किसी विशेष पूजा या अनुष्ठान की, 
                या फिर किसी शुभ संस्कार की - हम सभी प्रकार की सेवाएं उपलब्ध कराते हैं।
              </p>
            </div>
          </div>

          <Card className="border-2">
            <CardContent className="p-8">
              <h3 className="text-2xl font-bold mb-6">हमारी विशेषताएं</h3>
              <ul className="space-y-4">
                {features.map((feature, index) => (
                  <li key={index} className="flex items-start gap-3">
                    <CheckCircle2 className="h-6 w-6 text-primary flex-shrink-0 mt-0.5" />
                    <span className="text-base">{feature}</span>
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
}
