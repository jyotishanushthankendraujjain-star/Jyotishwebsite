import { Card } from '@/components/ui/card';

const galleryItems = [
  {
    title: 'हवन और यज्ञ',
    description: 'पवित्र अग्नि में आहुति',
  },
  {
    title: 'पूजा अनुष्ठान',
    description: 'विधिवत पूजा संपन्न',
  },
  {
    title: 'विवाह संस्कार',
    description: 'वैदिक विवाह विधि',
  },
  {
    title: 'मंत्र जाप',
    description: 'सामूहिक मंत्र उच्चारण',
  },
  {
    title: 'आरती और भजन',
    description: 'भक्ति संगीत कार्यक्रम',
  },
  {
    title: 'प्रसाद वितरण',
    description: 'पवित्र प्रसाद',
  },
];

export function Gallery() {
  return (
    <section id="gallery" className="py-20 md:py-28">
      <div className="container">
        <div className="mx-auto max-w-2xl text-center mb-16">
          <h2 className="text-3xl font-bold tracking-tight sm:text-4xl md:text-5xl mb-4">
            गैलरी
          </h2>
          <p className="text-lg text-muted-foreground">
            हमारे द्वारा संपन्न किए गए विभिन्न अनुष्ठानों की झलकियां
          </p>
        </div>

        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {galleryItems.map((item, index) => (
            <Card key={index} className="overflow-hidden group cursor-pointer transition-all hover:shadow-xl">
              <div className="aspect-[4/3] bg-gradient-to-br from-primary/20 via-accent/20 to-primary/20 relative overflow-hidden">
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="text-6xl opacity-20">🕉️</div>
                </div>
                <div className="absolute inset-0 bg-gradient-to-t from-background/90 to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end p-6">
                  <div>
                    <h3 className="text-xl font-bold mb-1">{item.title}</h3>
                    <p className="text-sm text-muted-foreground">{item.description}</p>
                  </div>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
