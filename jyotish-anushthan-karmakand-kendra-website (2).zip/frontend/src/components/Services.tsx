import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Flame, Star, BookOpen, Home, Heart, Users } from 'lucide-react';

const services = [
  {
    icon: Flame,
    title: 'हवन और यज्ञ',
    description: 'विभिन्न प्रकार के हवन, यज्ञ और अग्निहोत्र की व्यवस्था अनुभवी पंडितों द्वारा',
  },
  {
    icon: Star,
    title: 'ज्योतिष परामर्श',
    description: 'कुंडली विश्लेषण, भविष्यफल, रत्न परामर्श और ज्योतिषीय समाधान',
  },
  {
    icon: BookOpen,
    title: 'पूजा-पाठ',
    description: 'सत्यनारायण पूजा, रुद्राभिषेक, लक्ष्मी पूजन और अन्य धार्मिक अनुष्ठान',
  },
  {
    icon: Home,
    title: 'गृह प्रवेश और वास्तु',
    description: 'गृह प्रवेश पूजन, वास्तु शांति और वास्तु दोष निवारण',
  },
  {
    icon: Heart,
    title: 'विवाह संस्कार',
    description: 'विवाह, सगाई और अन्य शुभ संस्कारों का आयोजन वैदिक रीति से',
  },
  {
    icon: Users,
    title: 'अन्य संस्कार',
    description: 'नामकरण, मुंडन, यज्ञोपवीत और अन्य सभी संस्कारों की व्यवस्था',
  },
];

export function Services() {
  return (
    <section id="services" className="py-20 md:py-28">
      <div className="container">
        <div className="mx-auto max-w-2xl text-center mb-16">
          <h2 className="text-3xl font-bold tracking-tight sm:text-4xl md:text-5xl mb-4">
            हमारी सेवाएं
          </h2>
          <p className="text-lg text-muted-foreground">
            शास्त्रोक्त विधि से संपन्न होने वाली सभी प्रकार की धार्मिक और आध्यात्मिक सेवाएं
          </p>
        </div>

        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {services.map((service, index) => {
            const Icon = service.icon;
            return (
              <Card key={index} className="group transition-all hover:shadow-lg hover:border-primary/50">
                <CardHeader>
                  <div className="mb-4 inline-flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10 text-primary transition-colors group-hover:bg-primary group-hover:text-primary-foreground">
                    <Icon className="h-6 w-6" />
                  </div>
                  <CardTitle className="text-xl">{service.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-base">{service.description}</CardDescription>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>
    </section>
  );
}
