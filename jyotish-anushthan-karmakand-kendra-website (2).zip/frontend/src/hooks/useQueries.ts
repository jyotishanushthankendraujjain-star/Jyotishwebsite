// This file is intentionally minimal as the backend is empty
// and this is a static informational website

export function useQueries() {
  // No backend queries needed for this static website
  return {};
}
