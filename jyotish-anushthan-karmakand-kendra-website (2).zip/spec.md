# Jyotish Anushthan Karmakand Kendra Website

## Overview
A public website for Jyotish Anushthan Karmakand Kendra that presents the organization's information, services, and visuals in Hindi. The website will be built using the provided assets from the uploaded ZIP files, preserving the original structure and design as closely as possible.

## Core Features

### Content Display
- Display organization details and information in Hindi
- Present service information clearly and comprehensively
- Show all visual content from the provided assets
- Maintain the original structure and layout from the source files
- Ensure content is accessible on both desktop and mobile devices

### Asset Integration
- Extract and utilize all content from both provided ZIP files
- Preserve original design elements, images, and layout structure
- If HTML structure exists in the files, adapt it to React + Tailwind while maintaining identical appearance
- Display all images and visual assets as provided in the original files

### Responsive Design
- Ensure proper display on desktop devices
- Optimize layout and content for mobile viewing
- Maintain readability and usability across different screen sizes

## Technical Requirements

### Frontend
- Build using React with Tailwind CSS
- Adapt any existing HTML structure to React components
- Preserve original styling and visual appearance
- Implement responsive design for mobile compatibility
- Support Hindi language content display

### Content Management
- All content will be static, sourced from the provided ZIP files
- No dynamic content management required
- No user authentication needed
- No backend data storage required

## User Experience
- Users can browse organization information
- Users can view service details
- Users can access all visual content
- Content is presented in Hindi language
- Site works seamlessly on both desktop and mobile devices
